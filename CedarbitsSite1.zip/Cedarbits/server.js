const express = require("express");
const fs = require("fs");
const session = require("express-session");
const path = require("path");

const app = express();
const PORT = 3000;

/* =====================
   SESSION SETUP
===================== */
app.use(session({
  secret: "chaos-city-ics-secret",
  resave: false,
  saveUninitialized: false
}));

/* =====================
   MIDDLEWARE
===================== */
app.use(express.urlencoded({ extended: true }));

/* =====================
   BLOCK STATIC DASHBOARD ACCESS
===================== */
app.get("/ics-dashboard.html", (req, res) => {
  res.redirect("/ics-login.html");
});

/* =====================
   STATIC FILES
===================== */
app.use(express.static("public"));

/* =====================
   AUTH MIDDLEWARE
===================== */
function requireAuth(req, res, next) {
  if (req.session && req.session.authenticated) {
    next();
  } else {
    res.redirect("/ics-login.html");
  }
}

/* =====================
   ICS MESSAGE CONFIG
===================== */
const icsMessages = [
  {
    from: "Admin",
    message: "Chappie, stop forgetting your SSH password. I reset it to 'bluepuppy21' for you. Dont tell me you forgot to change your username too...",
    timestamp: () => new Date().toLocaleString()
  },
  {
    from: "Admin",
    message: "New Username System. All employees are to use their aliases as their usernames for our SSH server. Please change your username from your first name to your alias at your first opportunity. Dont forget!",
    timestamp: () => "1/15/2026, 8:00:00 AM"
  }
];

/* =====================
   MESSAGE API
===================== */
app.get("/ics-messages", requireAuth, (req, res) => {
  res.json(
    icsMessages.map(m => ({
      from: m.from,
      message: m.message,
      timestamp: m.timestamp()
    }))
  );
});

/* =====================
   PUBLIC CONTACT FORM
===================== */
app.post("/submit", (req, res) => {
  const { name, email, message } = req.body;

  const entry = `
------------------------
Name: ${name}
Email: ${email}
Message: ${message}
Date: ${new Date().toLocaleString()}
`;

  fs.appendFile("submissions.txt", entry, err => {
    if (err) {
      return res.status(500).send("Error saving submission.");
    }
    res.redirect("https://www.youtube.com/watch?v=dQw4w9WgXcQ");
  });
});

/* =====================
   ICS LOGIN
===================== */
app.post("/ics-login", (req, res) => {
  const { username, password } = req.body;

  fs.readFile("credentials.txt", "utf8", (err, data) => {
    if (err) {
      return res.status(500).send("Authentication system error.");
    }

    const valid = data
      .split("\n")
      .map(line => line.trim())
      .includes(`${username}:${password}`);

    if (valid) {
      req.session.authenticated = true;
      req.session.user = username;
      res.redirect("/ics-dashboard");
    } else {
      res.redirect("/ics-login.html?error=1");
    }
  });
});

/* =====================
   PROTECTED DASHBOARD
===================== */
app.get("/ics-dashboard", requireAuth, (req, res) => {
  res.sendFile(path.join(__dirname, "public", "ics-dashboard.html"));
});

/* =====================
   LOGOUT
===================== */
app.get("/ics-logout", (req, res) => {
  req.session.destroy(() => {
    res.redirect("/ics-login.html");
  });
});

/* =====================
   SERVER START
===================== */
app.listen(PORT, () => {
  console.log(`Chaos City DOT running at http://localhost:${PORT}`);
});

