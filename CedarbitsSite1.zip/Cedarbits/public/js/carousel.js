const slides = document.querySelectorAll(".carousel-slide");
const track = document.querySelector(".carousel-track");
const prevBtn = document.querySelector(".prev");
const nextBtn = document.querySelector(".next");
const dotsContainer = document.querySelector(".carousel-dots");

let currentIndex = 0;
let interval;

/* =====================
   CREATE DOTS
===================== */
slides.forEach((_, i) => {
  const dot = document.createElement("span");
  dot.classList.add("dot");
  if (i === 0) dot.classList.add("active");
  dot.addEventListener("click", () => goToSlide(i));
  dotsContainer.appendChild(dot);
});

const dots = document.querySelectorAll(".dot");

/* =====================
   FUNCTIONS
===================== */
function updateCarousel() {
  slides.forEach((slide, i) => {
    slide.classList.toggle("active", i === currentIndex);
    dots[i].classList.toggle("active", i === currentIndex);
  });
}

function goToSlide(index) {
  currentIndex = index;
  updateCarousel();
  resetInterval();
}

function nextSlide() {
  currentIndex = (currentIndex + 1) % slides.length;
  updateCarousel();
}

function prevSlide() {
  currentIndex = (currentIndex - 1 + slides.length) % slides.length;
  updateCarousel();
}

/* =====================
   EVENTS
===================== */
nextBtn.addEventListener("click", () => {
  nextSlide();
  resetInterval();
});

prevBtn.addEventListener("click", () => {
  prevSlide();
  resetInterval();
});

/* =====================
   AUTO ROTATE
===================== */
function startInterval() {
  interval = setInterval(nextSlide, 5000);
}

function resetInterval() {
  clearInterval(interval);
  startInterval();
}

startInterval();

