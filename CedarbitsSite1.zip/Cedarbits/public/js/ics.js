/* =====================
   MESSAGE POPUP LOGIC
===================== */
const messageButton = document.getElementById("messageButton");
const messagePopup = document.getElementById("messagePopup");
const closePopup = document.getElementById("closePopup");
const messageContent = document.getElementById("messageContent");

messageButton.onclick = () => {
  fetch("/ics-messages")
    .then(res => res.json())
    .then(messages => {
      messageContent.innerHTML = "";

      if (!messages.length) {
        messageContent.innerHTML = "<p>No new messages.</p>";
        return;
      }

      messages.forEach(msg => {
        const div = document.createElement("div");
        div.className = "message";

        div.innerHTML = `
          <strong>${msg.from}</strong>
          <span class="timestamp">${msg.timestamp}</span>
          <p>${msg.message}</p>
        `;

        messageContent.appendChild(div);
      });

      messagePopup.style.display = "block";
    });
};

closePopup.onclick = () => {
  messagePopup.style.display = "none";
};

/* =====================
   CHARTS
===================== */
new Chart(document.getElementById("trafficChart"), {
  type: "pie",
  data: {
    labels: ["Private Vehicles", "Public Transit", "Commercial"],
    datasets: [{
      data: [58, 27, 15]
    }]
  }
});

new Chart(document.getElementById("flowChart"), {
  type: "line",
  data: {
    labels: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
    datasets: [{
      label: "Vehicles / Day",
      data: [12000, 13500, 14200, 13800, 15000, 11000, 9000],
      fill: false
    }]
  }
});

