<link rel="stylesheet" href="/css/bootstrap.min.css">
<link rel="stylesheet" href="/css/global.css">
<script src="/js/bootstrap.bundle.min.js"></script>